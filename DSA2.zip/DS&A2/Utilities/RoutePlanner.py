import datetime


class RoutePlanner:

    def __init__(self, address_data, distance_data):
        self.address_data = address_data
        self.distance_data = distance_data
        self.Sorted_Queue = []
        self.Sorted_Distances = []

    def sort_nearest_neighbor(self, hub_address, package_queue, start_time, max_packages, average_speed):
        # not used
        sorted_distances = []
        nearest_neighbor, index, nearest_neighbor_distance = self.find_closest_delivery(hub_address, package_queue)
        self.Sorted_Queue.append(nearest_neighbor)
        sorted_distances.append(nearest_neighbor_distance)
        nearest_neighbor.est_time_arrival = start_time + datetime.timedelta(hours=sum(sorted_distances) / average_speed)
        package_queue.remove(nearest_neighbor)
        #
        while len(self.Sorted_Queue) < max_packages and package_queue:
            self.sort_nearest_neighbor(nearest_neighbor.delivery_address, package_queue, start_time, max_packages,
                                       average_speed)
        return self.Sorted_Queue

    def sort_nearest_neighbor_cluster(self, hub_address, package_queue, start_time, max_packages, average_speed):
        # not used
        nearest_neighbor, index, nearest_neighbor_distance = self.find_closest_delivery(hub_address, package_queue)
        self.Sorted_Queue.append(nearest_neighbor)
        package_queue.remove(nearest_neighbor)
        #
        while len(self.Sorted_Queue) < max_packages and package_queue:
            self.sort_nearest_neighbor_cluster(hub_address, package_queue, start_time, max_packages, average_speed)
        return self.Sorted_Queue

    def sort_furthest_neighbor_cluster(self, hub_address, package_queue, start_time, max_packages, average_speed):
        # not used / find the furthest delivery
        furthest_neighbor, index, furthest_neighbor_distance = self.find_furthest_delivery(hub_address, package_queue)
        # build nearest neighbor cluster around the furthest delivery
        cluster = [furthest_neighbor]
        package_queue.remove(furthest_neighbor)
        while len(cluster) < max_packages and package_queue:
            nearest_neighbor_head, index, nearest_neighbor_distance_head = \
                self.find_closest_delivery(cluster[0].delivery_address, package_queue)
            nearest_neighbor_tail, index, nearest_neighbor_distance_tail = \
                self.find_closest_delivery(cluster[-1].delivery_address, package_queue)
            if nearest_neighbor_distance_head <= nearest_neighbor_distance_tail:
                cluster.insert(0, nearest_neighbor_head)
                package_queue.remove(nearest_neighbor_head)
            else:
                cluster.append(nearest_neighbor_tail)
                package_queue.remove(nearest_neighbor_tail)

        self.Sorted_Queue = cluster
        return self.Sorted_Queue

    def sort_alt_furthest_neighbor_cluster(self, hub_address, package_queue, start_time, max_packages, average_speed):
        # not used/ find the furthest delivery
        furthest_neighbor, index, furthest_neighbor_distance = self.find_furthest_delivery(hub_address, package_queue)
        # build nearest neighbor cluster around the furthest delivery
        cluster = [furthest_neighbor]
        package_queue.remove(furthest_neighbor)
        while len(cluster) < max_packages and package_queue:
            nearest_neighbor_head, index, nearest_neighbor_distance_head = \
                self.find_closest_delivery(cluster[0].delivery_address, package_queue)
            nearest_neighbor_tail, index, nearest_neighbor_distance_tail = \
                self.find_closest_delivery(cluster[-1].delivery_address, package_queue)

            cluster.insert(0, nearest_neighbor_head)
            package_queue.remove(nearest_neighbor_head)

            cluster.append(nearest_neighbor_tail)
            package_queue.remove(nearest_neighbor_tail)

        self.Sorted_Queue = cluster
        return self.Sorted_Queue

    def sort_alt_furthest_neighbor_cluster_revamp(self, hub_address, priority_package_queue, standard_package_queue,
                                                  start_time, max_packages, average_speed):
        search_radius = 3

        # find the furthest delivery in queue(s)
        furthest_neighbor_prio, index, furthest_neighbor_distance_prio = self.find_furthest_delivery(hub_address, priority_package_queue)
        furthest_neighbor, index, furthest_neighbor_distance = self.find_furthest_delivery(hub_address, standard_package_queue)

        # find the furthest delivery in queue(s), add to cluster, remove from queue
        if furthest_neighbor_distance_prio > furthest_neighbor_distance:
            cluster = [furthest_neighbor_prio]
            priority_package_queue.remove(furthest_neighbor_prio)
        else:
            cluster = [furthest_neighbor]
            standard_package_queue.remove(furthest_neighbor)

        # build nearest neighbor cluster around the furthest delivery
        while len(cluster) < max_packages and priority_package_queue:
            # find the closest priority deliveries to head and tail of cluster
            closest_deliveries_prio_head = self.find_closest_deliveries(cluster[0].delivery_address,
                                                                        priority_package_queue)
            closest_deliveries_tail_prio = self.find_closest_deliveries(cluster[-1].delivery_address,
                                                                        priority_package_queue)
            # find the closest non-priority deliveries to head of cluster
            closest_deliveries_std = self.find_closest_deliveries(cluster[0].delivery_address, standard_package_queue)

            # if closest non-priority deliveries are closer than the next priority delivery and within the search radius
            # add them to cluster, remove from queue
            for delivery in closest_deliveries_std:
                if delivery[1] < closest_deliveries_prio_head[0][1] and delivery[1] < search_radius and len(cluster) < max_packages:
                    cluster.insert(0, delivery[0])
                    standard_package_queue.remove(delivery[0])

            # # find the closest non-priority deliveries to tail of cluster
            closest_deliveries_tail_std = self.find_closest_deliveries(cluster[-1].delivery_address,
                                                                       standard_package_queue)
            # if closest non-priority deliveries are closer than the next priority delivery and within the search radius
            # add them to cluster, remove from queue
            for delivery in closest_deliveries_tail_std:
                if delivery[1] < closest_deliveries_tail_prio[0][1] and delivery[1] < search_radius and len(cluster) < max_packages:
                    cluster.append(delivery[0])
                    standard_package_queue.remove(delivery[0])

            # check to see if head and tail are attempting to reach same priority delivery
            if closest_deliveries_prio_head[0][0] == closest_deliveries_tail_prio[0][0] and len(cluster) < max_packages:
                # assign it to whichever is closest, while the other picks it's second closest
                if closest_deliveries_prio_head[0][1] < closest_deliveries_tail_prio[0][1]:
                    cluster.insert(0, closest_deliveries_prio_head[0][0])
                    priority_package_queue.remove(closest_deliveries_prio_head[0][0])
                else:
                    cluster.append(closest_deliveries_tail_prio[0][0])
                    priority_package_queue.remove(closest_deliveries_tail_prio[0][0])
            # otherwise add both packages
            elif len(cluster) < max_packages:
                cluster.insert(0, closest_deliveries_prio_head[0][0])
                priority_package_queue.remove(closest_deliveries_prio_head[0][0])
                cluster.append(closest_deliveries_tail_prio[0][0])
                priority_package_queue.remove(closest_deliveries_tail_prio[0][0])

        self.Sorted_Queue = cluster
        return self.Sorted_Queue

    def sort_clusters(self, hub_address, package_queue, start_time, max_packages, average_speed):
        # not used
        cluster_queue = [[element] for element in package_queue]
        clusters_distances = [[] for element in package_queue]
        #
        for index, cluster in enumerate(cluster_queue):
            package_queue.remove(cluster[0])
            #
            while len(cluster) < max_packages and package_queue:
                nearest_neighbor_head, index, nearest_neighbor_distance_head = \
                    self.find_closest_delivery(cluster[0].delivery_address, package_queue)
                nearest_neighbor_tail, index, nearest_neighbor_distance_tail = \
                    self.find_closest_delivery(cluster[-1].delivery_address, package_queue)
                #
                if nearest_neighbor_distance_head > nearest_neighbor_distance_tail:
                    cluster.insert(0, nearest_neighbor_head)
                    clusters_distances[index].append(nearest_neighbor_distance_head)
                    package_queue.remove(nearest_neighbor_head)
                else:
                    cluster.append(nearest_neighbor_tail)
                    clusters_distances[index].append(nearest_neighbor_distance_head)
                    package_queue.remove(nearest_neighbor_tail)

            clusters_distances[index].append(self.distance_between(self.get_address_ID(hub_address),
                                                                   cluster[0].delivery_address))
            clusters_distances[index].append(self.distance_between(self.get_address_ID(hub_address),
                                                                   cluster[-1].delivery_address))

        shortest_cluster_distance = 1000
        shortest_cluster_index = 0

        for distance_index, distances in enumerate(clusters_distances):
            if sum(distances) < shortest_cluster_distance:
                shortest_cluster_distance = sum(distances)
                shortest_cluster_index = distance_index
        #
        self.Sorted_Queue = cluster_queue[shortest_cluster_index]
        return self.Sorted_Queue

    def optimize_brute_force(self, package_route):
        pass

    def find_closest_delivery(self, start_address, package_queue):
        closest_delivery = []
        index = 0
        min_distance = 100.0
        # finds distance to all packages
        for index, package in enumerate(package_queue):
            distance = self.distance_between(self.get_address_ID(start_address),
                                             self.get_address_ID(package.delivery_address))
            # finds the smallest distance and returns it
            if distance < min_distance:
                min_distance = distance
                closest_delivery = package
        return closest_delivery, index, min_distance

    def find_closest_deliveries(self, start_address, package_queue):
        closest_deliveries = []
        # finds distance to all packages and appends package and distance to list
        for package in package_queue:
            distance = self.distance_between(self.get_address_ID(start_address),
                                             self.get_address_ID(package.delivery_address))
            closest_deliveries.append([package, distance])
        # sorts list by distance and returns it
        closest_deliveries.sort(key=lambda x: x[1])
        return closest_deliveries

    def find_furthest_delivery(self, start_address, package_queue):
        furthest_delivery = []
        index = ''
        max_distance = 0
        # finds distance to all packages
        for index, package in enumerate(package_queue):
            distance = self.distance_between(self.get_address_ID(start_address),
                                             self.get_address_ID(package.delivery_address))
            # finds the largest distance and returns it
            if distance > max_distance:
                max_distance = distance
                furthest_delivery = package
        return furthest_delivery, index, max_distance

    def distance_between(self, start_address_ID, end_address_ID):
        # flips values if needed to properly access distance data
        if start_address_ID >= end_address_ID:
            return float(self.distance_data[start_address_ID][end_address_ID])
        else:
            return float(self.distance_data[end_address_ID][start_address_ID])

    def get_address_ID(self, address):
        # compares passed in address to available address data and returns matching address ID
        for a in self.address_data:
            if str(address) == a[2]:
                return int(a[0])
