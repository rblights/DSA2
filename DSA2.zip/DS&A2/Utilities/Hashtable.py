class ChainingHashTable:

    def __init__(self):
        # hashtable constructor with size list of prime numbers where size(n) >= 2 * size(n-1) + 1
        self.hashtable_size_list = [11, 23, 47, 97, 199]
        self.hashtable_size_list_iterator = 0
        self.item_count = 0
        self.load_factor = 1

        self.hashtable = [[] for i in range(self.hashtable_size_list[self.hashtable_size_list_iterator])]

    def insert(self, key, item):
        # locates bucket
        bucket = hash(key) % len(self.hashtable)
        bucket_list = self.hashtable[bucket]

        # updates existing value
        for key_value in bucket_list:
            if key_value[0] == key:
                key_value[1] = item
                return True
        # inserts new value and updates item count
        key_value = [key, item]
        bucket_list.append(key_value)
        self.item_count += 1

        # resizes and rehashes based on item count and load factor
        if self.item_count / len(self.hashtable) >= self.load_factor:
            self.hashtable_size_list_iterator += 1
            old_hashtable = self.hashtable
            self.hashtable = [[] for i in range(self.hashtable_size_list[self.hashtable_size_list_iterator])]
            for items in old_hashtable:
                for item in items:
                    self.insert(item[0], item[1])

        return True

    def search(self, key):
        # locates bucket
        bucket = hash(key) % len(self.hashtable)
        bucket_list = self.hashtable[bucket]

        # returns value if key is found
        for key_value in bucket_list:
            if key_value[0] == key:
                return key_value[1]
        return None

    def remove(self, key):
        # locates bucket
        bucket = hash(key) % len(self.hashtable)
        bucket_list = self.hashtable[bucket]

        # removes value if key is found
        for key_value in bucket_list:
            if key_value[0] == key:
                bucket_list.remove([key_value[0], key_value[1]])