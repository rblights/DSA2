class Package:

    def __init__(self, package_ID, delivery_address, delivery_city, delivery_state, delivery_zip, delivery_deadline,
                 package_weight, delivery_status, special_note):
        self.package_ID = package_ID
        self.delivery_address = delivery_address
        self.delivery_city = delivery_city
        self.delivery_zip = delivery_zip
        self.delivery_state = delivery_state
        self.est_time_arrival = ''
        self.delivery_deadline = delivery_deadline
        self.package_weight = package_weight
        self.delivery_status = delivery_status
        self.special_note = special_note

    def __str__(self):
        return "%s, %s, %s, %s, %s, ETA - %s, Deadline - %s, %s, %s, %s" % (self.package_ID, self.delivery_address,
                                                                            self.delivery_city, self.delivery_zip,
                                                                            self.delivery_state, self.est_time_arrival,
                                                                            self.delivery_deadline, self.package_weight,
                                                                            self.delivery_status, self.special_note)

