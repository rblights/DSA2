import csv

from Classes import Package, Truck, Driver
from Utilities import Hashtable, RoutePlanner


class Hub:

    def __init__(self, address, truck_count, driver_count, start_time, lookup_time, requested_package_ID):
        # hub constructor
        self.address = address
        self.truck_count = truck_count
        self.driver_count = driver_count
        self.start_time = start_time
        self.current_time = start_time
        self.lookup_time = lookup_time
        self.requested_package_ID = requested_package_ID

        # delivery data
        self.Packages_Hash_Table = Hashtable.ChainingHashTable()
        self.Distance_Data = []
        self.Address_Data = []

        # delivery queues
        self.Priority_Package_Queue = []
        self.Standard_Package_Queue = []
        self.NonStandard_Package_Queue = []
        self.Truck_Queue = []
        self.Loaded_Truck_Queue = []
        self.Ready_Truck_Queue = []
        self.Driver_Queue = []

    def load_package_data(self, csv_file, sort):
        # reads passed in packages csv
        with open(csv_file) as package_data:
            packages = csv.reader(package_data, delimiter=",")
            for package in packages:
                # assigns package attributes
                package_id = int(package[0])
                delivery_address = package[1]
                delivery_city = package[2]
                delivery_zip = package[3]
                delivery_state = package[4]
                delivery_deadline = package[5]
                package_weight = package[6]
                delivery_status = "At Hub"
                special_note = package[7]

                # creates new packages
                new_package = Package.Package(package_id, delivery_address, delivery_city, delivery_zip, delivery_state,
                                              delivery_deadline, package_weight, delivery_status, special_note)

                # adds packages to hashtable
                self.Packages_Hash_Table.insert(package_id, new_package)

                if sort:
                    # sort packages with deadlines
                    if new_package.delivery_deadline != 'EOD':
                        self.Priority_Package_Queue.append(new_package)
                    # sort packages with special notes
                    elif new_package.special_note == '':
                        self.Standard_Package_Queue.append(new_package)
                    else:
                        self.NonStandard_Package_Queue.append(new_package)
                else:
                    self.Standard_Package_Queue.append(new_package)

    def load_distance_data(self, csv_file):
        # reads passed in distances csv
        with open(csv_file) as distance_data:
            distances = csv.reader(distance_data, delimiter=",")
            for distance in distances:
                self.Distance_Data.append(distance)

    def load_address_data(self, csv_file):
        # reads passed in addresses csv
        with open(csv_file) as address_data:
            addresses = csv.reader(address_data, delimiter=",")
            for address in addresses:
                self.Address_Data.append(address)

    def new_truck(self, truck_ID, max_packages, average_speed, current_address):
        # initializes truck and adds to truck queue
        new_truck = Truck.Truck(truck_ID, self.address, max_packages, average_speed, current_address, self.Address_Data,
                                self.Distance_Data, self.lookup_time, self.requested_package_ID)
        self.Truck_Queue.append(new_truck)

    def new_driver(self, driver_ID):
        # initializes driver and adds to driver queue
        new_driver = Driver.Driver(driver_ID)
        self.Driver_Queue.append(new_driver)

    def load_packages(self, priority_package_queue, standard_package_queue, sorting_method, route_optimization, departure_time):
        # check for trucks and packages
        if self.Truck_Queue and priority_package_queue:
            # initialize new router
            self.Truck_Queue[0].route_optimization = route_optimization
            new_route_planner = RoutePlanner.RoutePlanner(self.Address_Data, self.Distance_Data)
            # sort packages depending on passed in method
            if sorting_method == 'Nearest Neighbor':
                package_route = new_route_planner.sort_nearest_neighbor(self.address, priority_package_queue,
                                                                        departure_time, self.Truck_Queue[0].max_packages,
                                                                        18)
            elif sorting_method == 'Nearest Neighbor Cluster':
                package_route = new_route_planner.sort_nearest_neighbor(self.address, priority_package_queue,
                                                                        departure_time, self.Truck_Queue[0].max_packages,
                                                                        18)

            elif sorting_method == 'Furthest Neighbor Cluster':
                package_route = new_route_planner.sort_furthest_neighbor_cluster(self.address, priority_package_queue,
                                                                                 departure_time,
                                                                                 self.Truck_Queue[0].max_packages, 18)
            elif sorting_method == 'Alt Furthest Neighbor Cluster':
                package_route = new_route_planner.sort_furthest_neighbor_cluster(self.address, priority_package_queue,
                                                                                 departure_time,
                                                                                 self.Truck_Queue[0].max_packages, 18)
            elif sorting_method == 'Alt Furthest Neighbor Cluster Revamp':
                package_route = \
                    new_route_planner.sort_alt_furthest_neighbor_cluster_revamp(self.address, priority_package_queue, standard_package_queue,
                                                                                departure_time,
                                                                                self.Truck_Queue[0].max_packages, 18)

            elif sorting_method == 'Clusters':
                package_route = new_route_planner.sort_clusters(self.address, priority_package_queue, departure_time,
                                                                self.Truck_Queue[0].max_packages, 18)

            # load packages until truck is full or no packages remain
            for i in range(0, self.Truck_Queue[0].max_packages):
                if package_route:
                    self.Truck_Queue[0].package_route.append(package_route.pop(0))
                    self.Truck_Queue[0].max_packages -= 1
                # remove loaded packages from queue(s)
                for package in priority_package_queue:
                    if package == self.Truck_Queue[0].package_route[-1]:
                        priority_package_queue.remove(package)
                for package in standard_package_queue:
                    if package == self.Truck_Queue[0].package_route[-1]:
                        standard_package_queue.remove(package)
        # if truck is fully loaded, add to loaded truck queue
        if self.Truck_Queue[0].max_packages == 0:
            self.Loaded_Truck_Queue.append(self.Truck_Queue.pop(0))
        # else check for more packages
        elif self.Priority_Package_Queue:
            self.load_packages(self.Priority_Package_Queue, self.Standard_Package_Queue, sorting_method,
                               route_optimization, departure_time)
        elif self.Standard_Package_Queue:
            self.load_packages(self.Standard_Package_Queue, self.NonStandard_Package_Queue, sorting_method,
                               route_optimization, departure_time)
        elif self.NonStandard_Package_Queue:
            self.load_packages(self.NonStandard_Package_Queue, self.NonStandard_Package_Queue, sorting_method,
                               route_optimization, departure_time)
        # if no packages remain, add to loaded truck queue
        else:
            self.Loaded_Truck_Queue.append(self.Truck_Queue.pop(0))

    def assign_driver(self):
        # check for loaded truck and unassigned driver
        if self.Loaded_Truck_Queue and self.Driver_Queue:
            # assign driver and add truck to ready queue
            ready_truck = self.Loaded_Truck_Queue.pop(0)
            ready_truck.driver_ID = self.Driver_Queue.pop(0)
            self.Ready_Truck_Queue.append(ready_truck)
            print("Truck " + str(ready_truck.truck_ID) + " - Driver Assigned and Awaiting Departure")
        else:
            # wait for driver
            if self.Loaded_Truck_Queue:
                print("\nPackages Loaded on Truck " + str(self.Loaded_Truck_Queue[0].truck_ID) +
                      " and Waiting for Driver\n")
                for package in self.Loaded_Truck_Queue[0].package_route:
                    print(self.Packages_Hash_Table.search(package.package_ID))

    def ready_truck_depart(self, departure_time):
        self.assign_driver()
        # next available truck begins route
        if self.Ready_Truck_Queue:
            self.Ready_Truck_Queue.pop(0).begin_route(departure_time, self.Packages_Hash_Table, self.Truck_Queue,
                                                      self.Driver_Queue)
