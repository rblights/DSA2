class Driver:

    def __init__(self, driver_ID):
        self.driver_ID = driver_ID
