import datetime
import sys

from Utilities import RoutePlanner


class Truck:

    def __init__(self, truck_ID, hub_address, max_packages, average_speed, current_address, address_data, distance_data,
                 lookup_time, requested_package_ID):
        # truck constructor
        self.truck_ID = truck_ID
        self.driver_ID = ''

        self.hub_address = hub_address
        self.max_packages = max_packages
        self.average_speed = average_speed
        self.package_route = []
        self.route_optimization = ''
        self.current_address = hub_address

        # delivery data
        self.address_data = address_data
        self.distance_data = distance_data

        # delivery status
        self.next_destination = ''
        self.delivered_packages = []
        self.departure_time = datetime.timedelta
        self.current_time = datetime.timedelta
        self.lookup_time = lookup_time
        self.distance_traveled = 0.0
        self.requested_package_ID = requested_package_ID

    def begin_route(self, departure_time, hashtable, truck_queue, driver_queue):
        # checks for and applies route optimization
        if self.route_optimization == 'Brute Force':
            new_router = RoutePlanner.RoutePlanner(self.address_data, self.distance_data)
            self.package_route = new_router.optimize_brute_force(self.package_route)
        elif self.route_optimization == 'Furthest Cluster Revamp':
            self.max_packages = 16
            new_router = RoutePlanner.RoutePlanner(self.address_data, self.distance_data)
            self.package_route = new_router.sort_alt_furthest_neighbor_cluster_revamp(self.hub_address,
                                                                                      self.package_route,
                                                                                      self.package_route,
                                                                                      departure_time, self.max_packages,
                                                                                      self.average_speed)
            # reverse route order to hit deadlines
            if self.truck_ID == 1 or self.truck_ID == 3:
                self.package_route.reverse()

        # set time and update package status
        self.departure_time = departure_time
        self.current_time = departure_time
        if self.package_route:
            print("\nTruck " + str(self.truck_ID) + " - Beginning Route at " + str(self.departure_time))
            for package in self.package_route:
                package.delivery_status = "En Route at " + str(self.departure_time)
                hashtable.insert(package.package_ID, package)
            self.deliver_packages(hashtable, truck_queue, driver_queue)

    def deliver_packages(self, hashtable, truck_queue, driver_queue):
        # while packages need to be delivered
        while self.package_route:
            # get next address
            self.next_destination = self.package_route[0].delivery_address
            # drive to next address/calculate distance(time)
            self.calculate_distance()
            # deliver package if not at or past requested lookup time
            if self.current_time < self.lookup_time:
                # update location and package status
                self.current_address = self.next_destination
                self.delivered_packages.append(self.package_route.pop(0))
                self.delivered_packages[-1].delivery_status = "Delivered at " + str(self.current_time)
                hashtable.insert(self.delivered_packages[-1].package_ID, self.delivered_packages[-1])
                self.max_packages += 1
            else:
                self.check_package_status(hashtable)
                break

        # return to hub when no packages remain
        if not self.package_route:
            self.next_destination = self.hub_address
            self.calculate_distance()
            self.returned_to_hub(truck_queue, driver_queue, hashtable)

    def returned_to_hub(self, truck_queue, driver_queue, hashtable):
        # add truck and driver to relevant queues at hub
        truck_queue.append(self)
        driver_queue.append(self.driver_ID)
        # display truck status - time of return and distance traveled
        print(
            "\nTruck " + str(self.truck_ID) + " - Returned to Hub at " + str(self.current_time) + ", Distance Traveled - "
            + str(self.distance_traveled) + " Miles")
        # display package status
        self.check_package_status(hashtable)

    def check_package_status(self, hashtable):
        # displays package status depending on requested lookup ID
        if self.requested_package_ID == "a":
            # all packages
            print("\nDelivered Packages at " + str(self.lookup_time))
            for package in self.delivered_packages:
                print(hashtable.search(package.package_ID))
            print("\nUndelivered Packages at " + str(self.lookup_time))
            for package in self.package_route:
                print(hashtable.search(package.package_ID))
        else:
            # specific ID
            for package in self.delivered_packages:
                if str(package.package_ID) == str(self.requested_package_ID):
                    print("\nRequested Package at " + str(self.lookup_time))
                    print(hashtable.search(package.package_ID))
                    sys.exit()
            for package in self.package_route:
                if str(package.package_ID) == str(self.requested_package_ID):
                    print("\nRequested Package at " + str(self.lookup_time))
                    print(hashtable.search(package.package_ID))
                    sys.exit()

    def calculate_distance(self):
        # gets distance between current address and next destination
        truck_router = RoutePlanner.RoutePlanner(self.address_data, self.distance_data)
        distance_traveled = truck_router.distance_between(truck_router.get_address_ID(self.current_address),
                                                          truck_router.get_address_ID(self.next_destination))
        # records distance traveled(and time)
        self.distance_traveled += distance_traveled
        self.current_time += datetime.timedelta(hours=distance_traveled / self.average_speed)

    def __str__(self):
        return "Truck ID - %s, %s, Max Packages - %s, Average Speed - %s, Departure Time - %s, Next Destination - %s," \
               " Packages - %s" % (self.truck_ID, self.driver_ID, self.max_packages, self.average_speed,
                                   self.departure_time, self.next_destination, self.package_route)
