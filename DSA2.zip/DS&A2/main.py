# Robert Lightsey, Student ID: 001204228

import datetime

from Classes import Hub


class Main:

    """

    Command Line Interface

    """

    print("\n\n\n---WGUPS Package Directory---")

    requested_time = input("\n\nEnter Time (Military Format - HH:MM:SS)\n\n")

    (H, M, S) = requested_time.split(":")
    lookup_time = datetime.timedelta(hours=int(H), minutes=int(M), seconds=int(S))

    requested_package_ID = input("\nEnter Package ID or (A) for (A)ll Packages\n\n")

    """
    
    Initialize WGUPS Hub
    
    """

    Hub_Address = "4001 South 700 East"
    Truck_Count = 3
    Driver_Count = 2
    Lookup_Time = lookup_time
    Current_Time = datetime.timedelta(hours=8)
    Requested_Package_ID = requested_package_ID.lower()

    WGUPS_Hub = Hub.Hub(Hub_Address, Truck_Count, Driver_Count, Current_Time, Lookup_Time, Requested_Package_ID)

    Sort_Packages_Into_Queues = True

    """Load Package, Distance, and Address Data"""

    WGUPS_Hub.load_package_data('CSVs/packages.csv', Sort_Packages_Into_Queues)

    WGUPS_Hub.load_distance_data('CSVs/distances.csv')

    WGUPS_Hub.load_address_data('CSVs/addresses.csv')

    """Initialize Trucks"""

    Max_Packages = 16
    Average_Speed = 18

    for i in range(0, WGUPS_Hub.truck_count):
        WGUPS_Hub.new_truck(i + 1, Max_Packages, Average_Speed, WGUPS_Hub.address)

    """Initialize Drivers"""

    for i in range(0, WGUPS_Hub.driver_count):
        WGUPS_Hub.new_driver(i + 1)

    """Sorting Controls"""

    Sorting_Method = 'Alt Furthest Neighbor Cluster Revamp'
    Route_Optimization = 'Furthest Cluster Revamp'
    Package_Constraints = True

    print("\nLoading Packages")

    WGUPS_Hub.load_packages(WGUPS_Hub.Priority_Package_Queue, WGUPS_Hub.Standard_Package_Queue, Sorting_Method, Route_Optimization,
                            datetime.timedelta(hours=8))

    # Truck 2 Delayed
    WGUPS_Hub.Truck_Queue.append(WGUPS_Hub.Truck_Queue.pop(0))

    WGUPS_Hub.load_packages(WGUPS_Hub.Priority_Package_Queue, WGUPS_Hub.Standard_Package_Queue, Sorting_Method, Route_Optimization,
                            datetime.timedelta(hours=8))

    WGUPS_Hub.load_packages(WGUPS_Hub.Priority_Package_Queue, WGUPS_Hub.Standard_Package_Queue, Sorting_Method, Route_Optimization,
                            datetime.timedelta(hours=10, minutes=20))

    print("---")

    """Transfer Packages

    Packages swapped in trucks per special notes
    """

    if Sorting_Method == "Alt Furthest Neighbor Cluster Revamp" and Package_Constraints:

        for package in WGUPS_Hub.Loaded_Truck_Queue[0].package_route:
            if package.package_ID == 20 or package.package_ID == 13 or package.package_ID == 19:
                WGUPS_Hub.Loaded_Truck_Queue[1].package_route.insert(6, package)
                WGUPS_Hub.Loaded_Truck_Queue[0].package_route.remove(package)

        for package in WGUPS_Hub.Loaded_Truck_Queue[1].package_route:
            if package.package_ID == 25 or package.package_ID == 26:
                WGUPS_Hub.Loaded_Truck_Queue[0].package_route.append(package)
                WGUPS_Hub.Loaded_Truck_Queue[1].package_route.remove(package)

        for package in WGUPS_Hub.Loaded_Truck_Queue[1].package_route:
            if package.package_ID == 18:
                WGUPS_Hub.Loaded_Truck_Queue[2].package_route.append(package)
                WGUPS_Hub.Loaded_Truck_Queue[1].package_route.remove(package)

    """Truck Departure"""

    # Truck 1
    WGUPS_Hub.ready_truck_depart(datetime.timedelta(hours=9, minutes=5))
    print("---")

    print("\nTruck 2 Delayed\n")
    print("---")

    # Truck 3
    WGUPS_Hub.ready_truck_depart(datetime.timedelta(hours=8))
    print("---")

    # package 9 address correction
    for package in WGUPS_Hub.Loaded_Truck_Queue[0].package_route:
        if package.package_ID == 9:
            package.delivery_address = '410 S State St'
            package.delivery_zip = '84111'
            WGUPS_Hub.Packages_Hash_Table.insert(package.package_ID, package)

    # Truck 2
    WGUPS_Hub.ready_truck_depart(datetime.timedelta(hours=10, minutes=42))
    print("---")


